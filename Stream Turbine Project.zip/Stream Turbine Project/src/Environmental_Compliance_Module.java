import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;

public class Environmental_Compliance_Module extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField compliance_id;
	private JTextField boiler_id;
	private JTextField emission_level;
	private JTextField compliance_status;
	private JTextField remarks;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Environmental_Compliance_Module frame = new Environmental_Compliance_Module();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	 public void auto_id()
	 {
		 
		  int count=1;
			try
	     	{
				Connection cn=null;
				Statement st=null;
				
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     		st=cn.createStatement();
	     		String sql="select * from environmental_compliance_module";
	     		ResultSet rs=st.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("compliance_id"));
	     			count++;
	     		}
	     	
	     		compliance_id.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	         System.out.println(ex.toString());
	     }
	}

	
	/**
	 * Create the frame.
	 */
	public Environmental_Compliance_Module() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1180, 742);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 11, 1144, 681);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Environmental Compliance Module");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(282, 27, 630, 33);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Compliance ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(85, 142, 187, 27);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Boiler ID");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(85, 213, 187, 27);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Emission Type");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_1.setBounds(85, 295, 187, 27);
		panel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Emission Level");
		lblNewLabel_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_2.setBounds(85, 383, 187, 27);
		panel.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("Compliance Date");
		lblNewLabel_1_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_3.setBounds(598, 142, 187, 27);
		panel.add(lblNewLabel_1_1_3);
		
		JLabel lblNewLabel_1_1_4 = new JLabel("Compliance Status");
		lblNewLabel_1_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_4.setBounds(598, 225, 187, 27);
		panel.add(lblNewLabel_1_1_4);
		
		JLabel lblNewLabel_1_1_5 = new JLabel("Remarks");
		lblNewLabel_1_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_5.setBounds(598, 307, 187, 27);
		panel.add(lblNewLabel_1_1_5);
		
		compliance_id = new JTextField();
		compliance_id.setBounds(282, 142, 119, 27);
		panel.add(compliance_id);
		compliance_id.setColumns(10);
		
		boiler_id = new JTextField();
		boiler_id.setColumns(10);
		boiler_id.setBounds(282, 213, 119, 27);
		panel.add(boiler_id);
		
		emission_level = new JTextField();
		emission_level.setColumns(10);
		emission_level.setBounds(282, 383, 228, 27);
		panel.add(emission_level);
		
		compliance_status = new JTextField();
		compliance_status.setColumns(10);
		compliance_status.setBounds(795, 222, 228, 27);
		panel.add(compliance_status);
		
		remarks = new JTextField();
		remarks.setColumns(10);
		remarks.setBounds(795, 304, 228, 27);
		panel.add(remarks);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "delete from environmental_compliance_module where compliance_id = '"+compliance_id.getText()+"' ";
					String result = db.delete(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDelete.setBounds(383, 574, 109, 33);
		panel.add(btnDelete);
		
		JButton btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Environmental_Compliance_Module obj = new View_Environmental_Compliance_Module();
				obj.setVisible(true);
			}
		});
		btnView.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnView.setBounds(740, 574, 109, 33);
		panel.add(btnView);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnSearch.addActionListener(new ActionListener() {
			private JDateChooser compliance_date;

			public void actionPerformed(ActionEvent e) {
				String Compliance_id=compliance_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from environmental_compliance_module where compliance_id='"+Compliance_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			emission_level.setText(rs.getString("emission_level"));
	          			compliance_status.setText(rs.getString("compliance_status"));
	          			remarks.setText(rs.getString("remarks"));
	          			compliance_date.setDate(rs.getDate("compliance_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSearch.setBounds(401, 142, 131, 27);
		panel.add(btnSearch);
		
		JButton btnSearch_1 = new JButton("Search");
		btnSearch_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnSearch_1.addActionListener(new ActionListener() {
			private JDateChooser compliance_date;

			public void actionPerformed(ActionEvent e) {
				String  Boiler_id= boiler_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from environmental_compliance_module where  boiler_id='"+ Boiler_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			emission_level.setText(rs.getString("emission_level"));
	          			compliance_status.setText(rs.getString("compliance_status"));
	          			remarks.setText(rs.getString("remarks"));
	          			compliance_date.setDate(rs.getDate("compliance.date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnSearch_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSearch_1.setBounds(401, 213, 131, 27);
		panel.add(btnSearch_1);
		
		JComboBox emission_type = new JComboBox();
		emission_type.setModel(new DefaultComboBoxModel(new String[] {"CO2", "SO2", "NOx"}));
		emission_type.setFont(new Font("Tahoma", Font.BOLD, 18));
		emission_type.setBounds(282, 295, 228, 27);
		panel.add(emission_type);
		
		JDateChooser compliance_date = new JDateChooser();
		compliance_date.setBounds(795, 142, 228, 27);
		panel.add(compliance_date);
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(1027, 11, 107, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "update environmental_compliance_module set compliance_id = '"+compliance_id.getText()+"' , boiler_id='"+boiler_id.getText()+"' , compliance_date='"+compliance_date.getDate()+"' ,  emission_level= '"+emission_level.getText()+"' , compliance_status='"+compliance_status.getText()+"' ,  remarks='"+remarks.getText()+"'  where compliance_id='"+compliance_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(217, 575, 114, 31);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date date = compliance_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String c_date = formatter.format(date);
				try
				{
					String sql = "insert into environmental_compliance_module ( compliance_id , compliance_date, boiler_id  , emission_type , compliance_status ,  remarks  ,emission_level ) values ( '"+ compliance_id.getText()+"', '"+ c_date+"','"+boiler_id.getText()+"' ,  '"+compliance_status.getText()+"','"+emission_type.getSelectedItem()+"' ,  '"+remarks.getText()+"','"+emission_level .getText()+"' ) ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(58, 575, 98, 31);
		panel.add(btnNewButton);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					compliance_id.setText("");
					boiler_id.setText("");
					emission_level.setText("");
					compliance_status.setText("");
					remarks.setText("");
					compliance_date.setDate(null);
					auto_id();
				}
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(550, 574, 131, 33);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Generate Report");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Environmental Compliance.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_4.setBounds(903, 573, 183, 35);
		panel.add(btnNewButton_4);
		auto_id();
	}
}
