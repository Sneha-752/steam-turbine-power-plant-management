import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import com.toedter.calendar.JDateChooser;

import net.proteanit.sql.DbUtils;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.Color;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class Energy_Sales_Module extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField sale_id;
	private JTextField customer_name;
	private JTextField customer_address;
	private JTextField contact_number;
	private JTextField energy_sold;
	private JTextField rate;
	private JTextField total_amount;
	private JTextField payment_status;
	private JTextField remarks;
    private JTextField sale_date;
    private JTable table;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Energy_Sales_Module frame = new Energy_Sales_Module();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	 public void auto_id()
	 {
		
		  int count=1;
			try
	     	{
				Connection cn=null;
				Statement st=null;
				
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     		st=cn.createStatement();
	     		String sql="select * from energy_sales_module";
	     		ResultSet rs=st.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("sale_id"));
	     			count++;
	     		}
	     		
	     		sale_id.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	         System.out.println(ex.toString());
	     }
	}
	
	/**
	 * Create the frame.
	 */
	
	protected void fetch()
	{
		try
	  	{
			Connection cn=null;
			Statement st=null;
			PreparedStatement pst=null;
	  		Class.forName("com.mysql.jdbc.Driver");
	  		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	  	    st=cn.createStatement();
	  		String sql="select * from energy_sales_module ";
	  		ResultSet rs=st.executeQuery(sql);
	  	    table.setModel(DbUtils.resultSetToTableModel(rs));
	        
	  	}
		catch(Exception ex)
		{
			JOptionPane.showInternalMessageDialog(null,ex.toString());
	  	}
	}
	public Energy_Sales_Module() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1404, 784);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(158, 11, 1024, 728);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Energy Sales Module");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(348, 34, 431, 49);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Sale ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(61, 126, 125, 32);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Customer Name");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(536, 126, 150, 32);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Customer Address");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(28, 245, 188, 32);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Contact Number");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(534, 187, 162, 32);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Energy Sold");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_4.setBounds(524, 245, 162, 32);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Rate");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_5.setBounds(61, 294, 125, 32);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Total Amount");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_6.setBounds(61, 349, 125, 32);
		panel.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Sale Date");
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_7.setBounds(61, 187, 125, 32);
		panel.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Payment Status\r\n");
		lblNewLabel_1_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_8.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_8.setBounds(508, 294, 188, 32);
		panel.add(lblNewLabel_1_8);
		
		JLabel lblNewLabel_1_9 = new JLabel("Remarks");
		lblNewLabel_1_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_9.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_9.setBounds(545, 349, 125, 32);
		panel.add(lblNewLabel_1_9);
		
		sale_id = new JTextField();
		sale_id.setBounds(241, 131, 137, 23);
		panel.add(sale_id);
		sale_id.setColumns(10);
		
		customer_name = new JTextField();
		customer_name.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (Character.isAlphabetic(evt.getKeyChar())  || evt.getKeyCode()==46 || evt.getKeyCode()==32 || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {
					customer_name.setEditable(true);
				        
				    }
				 else 
				{
					 customer_name.setEditable(false);
				       
				    }

			}
		});
		customer_name.setColumns(10);
		customer_name.setBounds(718, 134, 253, 23);
		panel.add(customer_name);
		
		customer_address = new JTextField();
		customer_address.setColumns(10);
		customer_address.setBounds(241, 253, 272, 23);
		panel.add(customer_address);
		
		contact_number = new JTextField();
		contact_number.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {

					contact_number.setEditable(true);

				}
				 else
				 {
					 contact_number.setEditable(false);

				}

			}
		});
		contact_number.setColumns(10);
		contact_number.setBounds(718, 195, 253, 23);
		panel.add(contact_number);
		
		energy_sold = new JTextField();
		energy_sold.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Double rate1 = Double.parseDouble(rate.getText());
				Double e_sold = Double.parseDouble(energy_sold.getText());
				Double total_c = rate1 * e_sold;
				total_amount.setText(String.valueOf(total_c));
			}
		});
		energy_sold.setColumns(10);
		energy_sold.setBounds(718, 253, 253, 23);
		panel.add(energy_sold);
		
		rate = new JTextField();
		rate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		rate.setColumns(10);
		rate.setBounds(241, 302, 272, 23);
		panel.add(rate);
		
		total_amount = new JTextField();
		total_amount.setColumns(10);
		total_amount.setBounds(241, 357, 272, 23);
		panel.add(total_amount);
		
		payment_status = new JTextField();
		payment_status.setColumns(10);
		payment_status.setBounds(718, 302, 253, 23);
		panel.add(payment_status);
		
		remarks = new JTextField();
		remarks.setColumns(10);
		remarks.setBounds(718, 357, 253, 23);
		panel.add(remarks);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "delete from energy_sales_module where sale_id = '"+sale_id.getText()+"' ";
					String result = db.delete(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDelete.setBounds(400, 670, 113, 37);
		panel.add(btnDelete);
		
		JButton btnGenerateReport = new JButton("Generate Report");
		btnGenerateReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = sale_id.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\energy_sale_bill_report.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters = new HashMap();
			           parameters.put("id", id);
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}

			
		});
		btnGenerateReport.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnGenerateReport.setBounds(749, 670, 197, 37);
		panel.add(btnGenerateReport);
		
		JDateChooser sale_date = new JDateChooser();
		sale_date.setBounds(241, 197, 272, 23);
		panel.add(sale_date);
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(886, 11, 113, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Date date = sale_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String s_date = formatter.format(date);
				try
				{
					String sql = "update energy_sales_module set sale_id = '"+sale_id.getText()+"' , sale_date = '"+s_date+"' , customer_name='"+customer_name.getText()+"' ,  customer_address= '"+customer_address.getText()+"' , contact_number='"+contact_number.getText()+"' ,  energy_sold='"+energy_sold.getText()+"' ,  rate='"+rate.getText()+"' ,  total_amount='"+total_amount.getText()+"' , payment_status='"+payment_status.getText()+"' , remarks='"+remarks.getText()+"' where sale_id='"+sale_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(225, 670, 113, 36);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date date = sale_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String s_date = formatter.format(date);
				
				try
				{
					String sql = "insert into energy_sales_module ( sale_id , customer_name  , sale_date , contact_number ,customer_address ,  energy_sold , rate  , payment_status , total_amount , remarks ) values ( '"+ sale_id.getText()+"' , '"+customer_name.getText()+"' ,'"+s_date+"', '"+customer_address .getText()+"' , '"+contact_number.getText()+"' , '"+energy_sold.getText()+"' , '"+rate.getText()+"','"+payment_status.getText()+"',  '"+total_amount.getText()+"' , '"+remarks.getText()+"' ) ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(63, 670, 101, 36);
		panel.add(btnNewButton);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sale_id.setText("");
				customer_name.setText("");
				customer_address.setText("");
				contact_number.setText("");
				energy_sold.setText("");
				rate.setText("");
				total_amount.setText("");
				payment_status.setText("");
				remarks.setText("");
				sale_date.setDate(null);
				auto_id();
			}
		});
		btnNewButton_3.setBounds(580, 670, 106, 37);
		panel.add(btnNewButton_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(38, 452, 935, 182);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_4 = new JButton("Search");
		btnNewButton_4.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Sale_id=sale_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from  energy_sales_module where sale_id='"+Sale_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			customer_name.setText(rs.getString("customer_name"));
	          			customer_address.setText(rs.getString("customer_address"));
	          			contact_number.setText(rs.getString("contact_number"));
	          			energy_sold.setText(rs.getString("energy_sold"));
	          			rate.setText(rs.getString("rate"));
	          			total_amount.setText(rs.getString("total_amount"));
	          			payment_status.setText(rs.getString("payment_status"));
	          			remarks.setText(rs.getString("remarks"));
	          			sale_date.setDate(rs.getDate("sale_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_4.setBounds(381, 131, 137, 23);
		panel.add(btnNewButton_4);
		
		fetch();
		
		auto_id();
	}
}
