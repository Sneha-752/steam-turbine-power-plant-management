import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Workers_Management extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField worker_id;
	private JTextField address;
	private JTextField desiganation;
	private JTextField qualification;
	private JTextField salary;
	private JTextField worker_name;
	private JTextField contact;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Workers_Management frame = new Workers_Management();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	 public void auto_id()
	   {
		  String var = "";
		  int count=1;
		  
			try
	     	{
				Connection cn=null;
				Statement st=null;
				
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     		st=cn.createStatement();
	     		String sql="select * from workers_management";
	     		ResultSet rs=st.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("worker_id"));
	     			count++;
	     		}
	     		var = String.valueOf(count);
	     		worker_id.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	         System.out.println(ex.toString());
	     }
			
	   }

	/**
	 * Create the frame.
	 */
	public Workers_Management() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1250, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setForeground(new Color(0, 0, 0));
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBounds(10, 11, 1214, 738);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Workers Management");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(319, 32, 517, 49);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Worker ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(60, 153, 177, 27);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Address");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(60, 237, 177, 27);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Birth Date");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(60, 329, 177, 27);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Desiganation");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_3.setBounds(60, 418, 177, 27);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Qualification");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_4.setBounds(60, 501, 177, 27);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Worker Name");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_5.setBounds(647, 153, 177, 27);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Contact");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_6.setBounds(647, 237, 177, 27);
		panel.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Joining Date");
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_7.setBounds(647, 329, 177, 27);
		panel.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Gender");
		lblNewLabel_1_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_8.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_8.setBounds(647, 418, 177, 27);
		panel.add(lblNewLabel_1_8);
		
		JLabel lblNewLabel_1_9 = new JLabel("Salary");
		lblNewLabel_1_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_9.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_9.setBounds(647, 509, 177, 27);
		panel.add(lblNewLabel_1_9);
		
		worker_id = new JTextField();
		worker_id.setBounds(267, 153, 177, 32);
		panel.add(worker_id);
		worker_id.setColumns(10);
		
		address = new JTextField();
		address.setColumns(10);
		address.setBounds(267, 241, 308, 32);
		panel.add(address);
		
		desiganation = new JTextField();
		desiganation.setColumns(10);
		desiganation.setBounds(267, 418, 308, 32);
		panel.add(desiganation);
		
		qualification = new JTextField();
		qualification.setColumns(10);
		qualification.setBounds(267, 505, 308, 31);
		panel.add(qualification);
		
		salary = new JTextField();
		salary.setColumns(10);
		salary.setBounds(834, 501, 308, 35);
		panel.add(salary);
		
		worker_name = new JTextField();
		worker_name.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				
				if (Character.isAlphabetic(evt.getKeyChar())  || evt.getKeyCode()==46 || evt.getKeyCode()==32 || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {
					worker_name.setEditable(true);
				        
				    }
				 else 
				{
					 worker_name.setEditable(false);
				       
				    }

				
			}
		});
		worker_name.setColumns(10);
		worker_name.setBounds(834, 153, 308, 31);
		panel.add(worker_name);
		
		contact = new JTextField();
		contact.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' && contact.getText().length()<10 || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {

					contact.setEditable(true);

				}
				 else
				 {
					 contact.setEditable(false);

				}

			}
		});
		contact.setColumns(10);
		contact.setBounds(834, 232, 308, 32);
		panel.add(contact);
		
		JDateChooser joining_date = new JDateChooser();
		joining_date.setBounds(834, 329, 308, 32);
		panel.add(joining_date);
		
		JDateChooser birth_date = new JDateChooser();
		birth_date.setBounds(267, 329, 308, 32);
		panel.add(birth_date);
		
		JComboBox gender = new JComboBox();
		gender.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female", "Other"}));
		gender.setFont(new Font("Tahoma", Font.BOLD, 20));
		gender.setBounds(834, 417, 295, 32);
		panel.add(gender);
		
		JButton btnNewButton = new JButton("View");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				View_Workers_Management obj = new View_Workers_Management();
				obj.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(855, 622, 89, 42);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Add");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try
				{
					String sql = "insert into Workers_Management (worker_id , address  , desiganation , qualification , salary , worker_name ,contact,gender ,birth_date,joining_date) values ( '"+worker_id.getText()+"' , '"+address.getText()+"' , '"+desiganation .getText()+"' , '"+qualification.getText()+"' , '"+salary.getText()+"' , '"+worker_name.getText()+"', '"+contact.getText()+"' ,'"+gender.getSelectedItem()+"' ,'"+birth_date.getDate()+"' , '"+joining_date.getDate()+"') ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					System.out.println(ex.toString());
				}
				
				
			}
			
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(208, 622, 89, 42);
		panel.add(btnNewButton_1);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "update Workers_Management set worker_id = '"+worker_id.getText()+"' , address='"+address.getText()+"' ,  desiganation= '"+desiganation.getText()+"' , qualification='"+qualification.getText()+"' ,  salary='"+salary.getText()+"' ,  birth_date='"+birth_date.getDate()+"' , joining_date='"+joining_date.getDate()+"' , worker_name='"+worker_name.getText()+"' ,  contact='"+contact.getText()+"' ,  gender='"+gender.getSelectedItem()+"'where worker_id='"+worker_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnUpdate.setBounds(367, 622, 105, 42);
		panel.add(btnUpdate);
		
		JButton btnNewButton_2_1 = new JButton("Delete");
		btnNewButton_2_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2_1.setBounds(532, 622, 105, 42);
		panel.add(btnNewButton_2_1);
		
		JButton btnNewButton_2_2 = new JButton("Clear");
		btnNewButton_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				worker_id.setText("");
				address.setText("");
				desiganation.setText("");
				qualification.setText("");
				salary.setText("");
				worker_name.setText("");
				contact.setText("");
				birth_date.setDate(null);
				joining_date.setDate(null);
				gender.setSelectedItem("gender");
				auto_id();
			}
		});
		btnNewButton_2_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2_2.setBounds(703, 622, 89, 42);
		panel.add(btnNewButton_2_2);
		
		JButton btnNewButton_2_3 = new JButton("Search");
		btnNewButton_2_3.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnNewButton_2_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Worker_id=worker_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from Workers_Management where worker_id='"+Worker_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			address.setText(rs.getString("address"));
	          			desiganation.setText(rs.getString("desiganation"));
	          			qualification.setText(rs.getString("qualification"));
	          			salary.setText(rs.getString("salary"));
	          			worker_name.setText(rs.getString("worker_name"));
	          			contact.setText(rs.getString("contact"));
	          			birth_date.setDate(rs.getDate("birth_date"));
	          			joining_date.setDate(rs.getDate("joining_date"));
	          			
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
				
			
			}
		});
		btnNewButton_2_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2_3.setBounds(454, 153, 132, 32);
		panel.add(btnNewButton_2_3);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj =new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(1068, 22, 99, 32);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Generate Report");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Workers Management.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
			
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(997, 622, 185, 36);
		panel.add(btnNewButton_3);
		
		auto_id();
	}
}
