import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Energy_Production_Module extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField production_id;
	private JTextField boiler_id;
	private JTextField fuel_id;
	private JTextField steam_generated;
	private JTextField power_generated;
	private JTextField production_time;
	private JTextField operator_name;
	private JTextField remarks;
	protected String date1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Energy_Production_Module frame = new Energy_Production_Module();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	 public void auto_id()
	 {
		
		  int count=1;
			try
	     	{
				Connection cn=null;
				Statement st=null;
				PreparedStatement pst = null;
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     	
	     		String sql="select * from energy_production_module";
	     		pst = cn.prepareStatement(sql);
	     		ResultSet rs=pst.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("production_id"));
	     			count++;
	     		}
	     		
	     		 production_id.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	         System.out.println(ex.toString());
	     }
			
	}
	/**
	 * Create the frame.
	 */
	public Energy_Production_Module() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1180, 733);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 11, 1144, 673);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Energy Production Module");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setBounds(274, 39, 575, 49);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Production ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(52, 144, 149, 36);
		panel.add(lblNewLabel_1);
		
		production_id = new JTextField();
		production_id.setBounds(257, 147, 156, 36);
		panel.add(production_id);
		production_id.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Boiler ID");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(52, 227, 149, 36);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Fuel ID");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(52, 306, 149, 36);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Steam Generated");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(36, 394, 211, 36);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Production Date");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_4.setBounds(690, 144, 149, 36);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Production Time");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_5.setBounds(690, 227, 149, 36);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Operator Name");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_6.setBounds(690, 306, 149, 36);
		panel.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Remarks");
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_7.setBounds(690, 394, 149, 36);
		panel.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Power Generated");
		lblNewLabel_1_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_8.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_8.setBounds(36, 473, 211, 36);
		panel.add(lblNewLabel_1_8);
		
		boiler_id = new JTextField();
		boiler_id.setColumns(10);
		boiler_id.setBounds(257, 230, 156, 36);
		panel.add(boiler_id);
		
		fuel_id = new JTextField();
		fuel_id.setColumns(10);
		fuel_id.setBounds(257, 309, 156, 36);
		panel.add(fuel_id);
		
		steam_generated = new JTextField();
		steam_generated.setColumns(10);
		steam_generated.setBounds(257, 397, 287, 36);
		panel.add(steam_generated);
		
		power_generated = new JTextField();
		power_generated.setColumns(10);
		power_generated.setBounds(257, 476, 287, 36);
		panel.add(power_generated);
		
		production_time = new JTextField();
		production_time.setColumns(10);
		production_time.setBounds(876, 227, 244, 36);
		panel.add(production_time);
		
		operator_name = new JTextField();
		operator_name.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (Character.isAlphabetic(evt.getKeyChar())  || evt.getKeyCode()==46 || evt.getKeyCode()==32 || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {
					operator_name.setEditable(true);
				        
				    }
				 else 
				{
					 operator_name.setEditable(false);
				       
				    }

			}
		});
		operator_name.setColumns(10);
		operator_name.setBounds(876, 306, 244, 36);
		panel.add(operator_name);
		
		remarks = new JTextField();
		remarks.setColumns(10);
		remarks.setBounds(876, 394, 244, 36);
		panel.add(remarks);
		
		JButton btnNewButton_2 = new JButton("Delete");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "delete from energy_production_module where production_id = '"+production_id.getText()+"' ";
					String result = db.delete(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(390, 564, 128, 45);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("View");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Energy_Production_Module obj = new View_Energy_Production_Module();
				obj.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(736, 564, 128, 45);
		panel.add(btnNewButton_3);
		
		JButton btnUpdate = new JButton("Generate Report");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Energy Production.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
			
		});
		
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnUpdate.setBounds(911, 564, 193, 45);
		panel.add(btnUpdate);
		
		JButton btnNewButton_1_1 = new JButton("Search");
		btnNewButton_1_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			private JDateChooser production_date;

			public void actionPerformed(ActionEvent e) {
				String Production_id=production_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from energy_production_module where production_id='"+Production_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			steam_generated.setText(rs.getString("steam_generated"));
	          			power_generated.setText(rs.getString("power_generated"));
	          			production_time.setText(rs.getString("production_time"));
	          			operator_name.setText(rs.getString("operator_name"));
	          			remarks.setText(rs.getString("remarks"));
	          			production_date.setDate(rs.getDate("production_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1_1.setBounds(416, 144, 139, 38);
		panel.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_2 = new JButton("Search");
		btnNewButton_1_2.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Boiler_id=boiler_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from energy_production_module where boiler_id='"+Boiler_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			steam_generated.setText(rs.getString("steam_generated"));
	          			power_generated.setText(rs.getString("power_generated"));
	          			production_time.setText(rs.getString("production_time"));
	          			operator_name.setText(rs.getString("operator_name"));
	          			remarks.setText(rs.getString("remarks"));
	          			
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnNewButton_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1_2.setBounds(416, 229, 139, 36);
		panel.add(btnNewButton_1_2);
		
		JButton btnNewButton_1_3 = new JButton("Search");
		btnNewButton_1_3.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnNewButton_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Fuel_id=fuel_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from energy_production_module where fuel_id='"+Fuel_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			steam_generated.setText(rs.getString("steam_generated"));
	          			power_generated.setText(rs.getString("power_generated"));
	          			production_time.setText(rs.getString("production_time"));
	          			operator_name.setText(rs.getString("operator_name"));
	          			remarks.setText(rs.getString("remarks"));
	          			
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnNewButton_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1_3.setBounds(416, 306, 139, 36);
		panel.add(btnNewButton_1_3);
		
		JDateChooser production_date = new JDateChooser();
		production_date.setBounds(876, 144, 244, 36);
		panel.add(production_date);
		
		JButton btnNewButton_4 = new JButton("EXIT");
		btnNewButton_4.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_4.setBounds(1020, 11, 114, 25);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date c_date = production_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String date1 = formatter.format(c_date);
				try
				{
					String sql = "insert into energy_production_module ( production_id , boiler_id  , fuel_id , steam_generated , power_generated , production_time ,operator_name , remarks , production_date ) values ( '"+ production_id.getText()+"' , '"+boiler_id.getText()+"' , '"+fuel_id .getText()+"' , '"+steam_generated.getText()+"' , '"+power_generated.getText()+"' , '"+production_time.getText()+"', '"+operator_name.getText()+"' ,  '"+remarks.getText()+"' , '"+date1+"'  ) ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(76, 564, 101, 45);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "update energy_production_module set production_id = '"+production_id.getText()+"' , boiler_id='"+boiler_id.getText()+"' ,  fuel_id= '"+fuel_id.getText()+"' , steam_generated='"+steam_generated.getText()+"' ,  power_generated='"+power_generated.getText()+"' ,  production_time='"+production_time.getText()+"' ,  operator_name='"+operator_name.getText()+"' ,  remarks='"+remarks.getText()+"' ,  production_date='"+date1+"' where production_id='"+production_id.getText()+"' "; 
					String result  = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(230, 564, 109, 45);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_5 = new JButton("Clear");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					production_id.setText("");
					boiler_id.setText("");
					fuel_id.setText("");
					steam_generated.setText("");
					power_generated.setText("");
					production_time.setText("");
					operator_name.setText("");
					remarks.setText("");
					production_date.setDate(null);
					auto_id();
				}
				
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_5.setBounds(573, 564, 101, 45);
		panel.add(btnNewButton_5);
		auto_id();
	}
}
