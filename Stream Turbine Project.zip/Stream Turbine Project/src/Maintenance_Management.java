import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Maintenance_Management extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField maintenance_id;
	private JTextField boiler_id;
	private JTextField maintenance_cost;
	private JTextField maintenance_description;
	private JTextField maintenance_engineer;
	private JTextField remarks;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Maintenance_Management frame = new Maintenance_Management();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public void auto_id()
	 {
		 
		  int count=1;
			try
	     	{
				Connection cn=null;
				Statement st=null;
				
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     		st=cn.createStatement();
	     		String sql="select * from  maintenance_management ";
	     		ResultSet rs=st.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("maintenance_id"));
	     			count++;
	     		}
	     	
	     		maintenance_id.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	         System.out.println(ex.toString());
	     }
	}
	

	/**
	 * Create the frame.
	 */
	public Maintenance_Management() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1180, 736);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 11, 1144, 675);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Maintenance Management ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel.setBounds(324, 39, 491, 43);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Maintenance ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(102, 132, 175, 25);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Boiler ID");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(102, 203, 175, 25);
		panel.add(lblNewLabel_1_1);
		
		JDateChooser maintenance_date = new JDateChooser();
		maintenance_date.setBounds(287, 346, 274, 32);
		panel.add(maintenance_date);
		
		JDateChooser next_maintenance_date = new JDateChooser();
		next_maintenance_date.setBounds(828, 278, 244, 25);
		panel.add(next_maintenance_date);
		
		JLabel lblNewLabel_1_2 = new JLabel("Maintenance Type");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(102, 278, 175, 25);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Maintenance Date");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(102, 353, 175, 25);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Maintenance Cost");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_4.setBounds(102, 431, 175, 25);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Maintenance Description");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_5.setBounds(576, 132, 244, 25);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Maintenance Engineer");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_6.setBounds(576, 203, 230, 25);
		panel.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel(" Next Maintenance Date");
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_7.setBounds(576, 278, 242, 25);
		panel.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Remark");
		lblNewLabel_1_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_8.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_8.setBounds(600, 358, 133, 25);
		panel.add(lblNewLabel_1_8);
		
		maintenance_id = new JTextField();
		maintenance_id.setBounds(287, 127, 133, 30);
		panel.add(maintenance_id);
		maintenance_id.setColumns(10);
		
		boiler_id = new JTextField();
		boiler_id.setColumns(10);
		boiler_id.setBounds(287, 203, 133, 30);
		panel.add(boiler_id);
		
		maintenance_cost = new JTextField();
		maintenance_cost.setColumns(10);
		maintenance_cost.setBounds(287, 426, 274, 30);
		panel.add(maintenance_cost);
		
		maintenance_description = new JTextField();
		maintenance_description.setColumns(10);
		maintenance_description.setBounds(830, 127, 242, 30);
		panel.add(maintenance_description);
		
		maintenance_engineer = new JTextField();
		maintenance_engineer.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
					if (Character.isAlphabetic(evt.getKeyChar())  || evt.getKeyCode()==46 || evt.getKeyCode()==32 || evt.getKeyCode() == evt.VK_BACK_SPACE)
					 {
						maintenance_engineer.setEditable(true);
					        
					    }
					 else 
					{
						 maintenance_engineer.setEditable(false);
					       
					    }

			}
		});
		maintenance_engineer.setColumns(10);
		maintenance_engineer.setBounds(830, 203, 242, 30);
		panel.add(maintenance_engineer);
		
		remarks = new JTextField();
		remarks.setColumns(10);
		remarks.setBounds(830, 353, 242, 30);
		panel.add(remarks);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "delete from maintenance_management where maintenance_id = '"+maintenance_id.getText()+"' ";
					String result = db.delete(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDelete.setBounds(395, 599, 103, 30);
		panel.add(btnDelete);
		
		JButton btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Maintenance_Management obj = new View_Maintenance_Management();
				obj.setVisible(true);
			}
		});
		btnView.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnView.setBounds(716, 599, 103, 30);
		panel.add(btnView);
		
		JButton btnGenerateReport = new JButton("Generate Report");
		btnGenerateReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Maintenance Management.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}

			
		});
		btnGenerateReport.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnGenerateReport.setBounds(875, 599, 197, 30);
		panel.add(btnGenerateReport);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Maintenance_id=maintenance_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from maintenance_management where maintenance_id='"+Maintenance_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			maintenance_cost.setText(rs.getString("maintenance_cost"));
	          			maintenance_description.setText(rs.getString("maintenance_description"));
	          			maintenance_engineer.setText(rs.getString("maintenance_engineer"));
	          			remarks.setText(rs.getString("remarks"));
	          			
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSearch.setBounds(428, 127, 133, 30);
		panel.add(btnSearch);
		
		JButton btnSearch_1 = new JButton("Search");
		btnSearch_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnSearch_1.addActionListener(new ActionListener() {
			private JDateChooser next_maintenance_date;
			private JDateChooser maintenance_date;

			public void actionPerformed(ActionEvent e) {
				String Boiler_id=boiler_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from maintenance_management where boiler_id='"+Boiler_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			maintenance_cost.setText(rs.getString("maintenance_cost"));
	          			maintenance_description.setText(rs.getString("maintenance_description"));
	          			maintenance_engineer.setText(rs.getString("maintenance_engineer"));
	          			remarks.setText(rs.getString("remarks"));
	          			next_maintenance_date.setDate(rs.getDate("next_maintenance_date"));
	          			maintenance_date.setDate(rs.getDate("maintenance_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnSearch_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSearch_1.setBounds(428, 203, 133, 30);
		panel.add(btnSearch_1);
		
		JComboBox maintenance_type = new JComboBox();
		maintenance_type.setFont(new Font("Tahoma", Font.BOLD, 18));
		maintenance_type.setModel(new DefaultComboBoxModel(new String[] {"Routine", "Overhaul"}));
		maintenance_type.setBounds(287, 278, 274, 26);
		panel.add(maintenance_type);
		
		
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(1018, 11, 116, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "update maintenance_management set maintenance_id = '"+maintenance_id.getText()+"' , boiler_id='"+boiler_id.getText()+"' ,  maintenance_cost= '"+maintenance_cost.getText()+"' ,  maintenance_date = '"+maintenance_date.getDate()+"' ,  next_maintenance_date = '"+next_maintenance_date.getDate()+"' , maintenance_description='"+maintenance_description.getText()+"' ,  maintenance_engineer='"+maintenance_engineer.getText()+"' , remarks='"+remarks.getText()+"'  where maintenance_id='"+maintenance_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton_2.setBounds(225, 598, 122, 32);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					maintenance_id.setText("");
					boiler_id.setText("");
					maintenance_cost.setText("");
					maintenance_description.setText("");
					maintenance_engineer.setText("");
					remarks.setText("");
					maintenance_date.setDate(null);
					next_maintenance_date.setDate(null);
					maintenance_type.setSelectedItem("Routine");
					auto_id();
				}	
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(561, 599, 89, 30);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "insert into maintenance_management ( maintenance_id , boiler_id  , maintenance_type , maintenance_cost , maintenance_description , maintenance_engineer , remarks , next_maintenance_date , maintenance_date ) values ( '"+ maintenance_id.getText()+"' , '"+boiler_id.getText()+"' ,'"+maintenance_type.getSelectedItem()+"' , '"+maintenance_cost .getText()+"' , '"+maintenance_description.getText()+"' , '"+maintenance_engineer.getText()+"' ,  '"+remarks.getText()+"', '"+maintenance_date.getDate()+"','"+next_maintenance_date.getDate()+"' ) ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					System.out.println(ex.toString());
				}


				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(77, 599, 103, 30);
		panel.add(btnNewButton);
		auto_id();
	}
}
