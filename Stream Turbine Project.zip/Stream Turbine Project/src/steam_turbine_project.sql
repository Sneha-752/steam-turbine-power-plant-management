create database steam_turbine_project;
use steam_turbine_project;

create table boiler_management
(
  boiler_id int auto_increment primary key,
  boiler_capacity nvarchar(50),
  boiler_type nvarchar(50),
  steam_pressure nvarchar(50),
  steam_temperature nvarchar(50),
  feed_water_temperature nvarchar(50),
  fuel_consumption_rate nvarchar(50),
  boiler_efficiency nvarchar(50),
  fuel_type nvarchar(150),
  last_maintenance_date nvarchar(50),
  next_maintenance_date nvarchar(50)
);

create table cost_estimation_module
(
  cost_id int auto_increment primary key,
  boiler_id nvarchar(50),
  modification_description nvarchar(50),
  estimated_cost nvarchar(50),
  actual_cost nvarchar(50),
  cost_date nvarchar(50),
  remarks nvarchar(50)
);


create table  environmental_compliance_module
(
  compliance_id int auto_increment primary key,
  compliance_date nvarchar(50),
  boiler_id nvarchar(50),
  compliance_status nvarchar(50),
  emission_type nvarchar(50),
  remarks nvarchar(50),
  emission_level nvarchar(50)
);

create table energy_production_module
(
  production_id int auto_increment primary key,
  boiler_id nvarchar(50),
  fuel_id nvarchar(50),
  steam_generated nvarchar(50),
  power_generated nvarchar(50),
  production_date nvarchar(50),
  production_time nvarchar(50),
  operator_name nvarchar(50),
  remarks nvarchar(50)
);

create table Fuel_Management
(
  fuel_id int auto_increment primary key,
  fuel_calorific_value nvarchar(50),
  fuel_type nvarchar(50),
  fuel_consumption_rate nvarchar(50),
  fuel_quantity nvarchar(50),
  last_delivery_date nvarchar(50),
  fuel_cost nvarchar(50),
  next_delivery_date nvarchar(50),
  fuel_supplier nvarchar(50)
);

create table energy_sales_module
(
  sale_id int auto_increment primary key,
  customer_name nvarchar(50),
  sale_date nvarchar(50),
  contact_number nvarchar(50),
  customer_address nvarchar(50),
  energy_sold nvarchar(50),
  rate nvarchar(50),
  payment_status nvarchar(50),
  total_amount nvarchar(50),
  remarks nvarchar(50)
);

create table  maintenance_management
(
  maintenance_id int auto_increment primary key,
  boiler_id nvarchar(50),
  maintenance_type nvarchar(50),
  maintenance_date nvarchar(50),
  maintenance_cost nvarchar(50),
  maintenance_description nvarchar(50),
  maintenance_engineer nvarchar(50),
  next_maintenance_date nvarchar(50),
  remarks nvarchar(50)
);



create table user_management
(
  user_id int auto_increment primary key,
  email_address nvarchar(50),
  user_name nvarchar(50),
  contact_number nvarchar(50),
  user_role nvarchar(50),
  last_login_date nvarchar(50),
  password nvarchar(50),
  remark nvarchar(50)
);

create table workers_management
(
  worker_id int auto_increment primary key,
  worker_name nvarchar(50),
  address nvarchar(50),
  contact nvarchar(50),
  birth_date nvarchar(50),
  joining_date nvarchar(50),
  desiganation nvarchar(50),
  qualification nvarchar(50),
  gender nvarchar(50),
  salary nvarchar(50)
  
);

create table workers_salary
(
  pay_no int auto_increment primary key,
  pay_date nvarchar(50),
  worker_id nvarchar(50),
  worker_name nvarchar(50),
  salary nvarchar(50),
  present_days nvarchar(50),
  absent_days nvarchar(50),
  deduct_amount nvarchar(50),
  net_salary nvarchar(50)
);



