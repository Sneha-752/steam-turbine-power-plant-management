import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JDayChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Workers_Salary extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField pay_no;
	private JTextField worker_id;
	private JTextField worker_name;
	private JTextField salary;
	private JTextField absent_days;
	private JTextField net_salary;
	private JTextField present_days;
	private JTextField deduct_amount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Workers_Salary frame = new Workers_Salary();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	 public void auto_id()
	   {
		  String var = "";
		  int count=1;
		  
			try
	     	{
				Connection cn=null;
				Statement st=null;
				PreparedStatement pst =null;
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     	
	     		String sql="select * from workers_salary";
	     		pst=cn.prepareStatement(sql);
	     		ResultSet rs=pst.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("pay_no"));
	     			count++;
	     		}
	     		var = String.valueOf(count);
	     		pay_no.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	         System.out.println(ex.toString());
	     }
			
	   }

	/**
	 * Create the frame.
	 */
	public Workers_Salary() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1250, 821);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBounds(10, 11, 1214, 727);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Workers Salary");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setBounds(387, 40, 489, 49);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Pay No");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(67, 121, 143, 36);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Worker Name");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(620, 224, 169, 36);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Pay Date");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(620, 124, 143, 36);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Present Days");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_3.setBounds(620, 317, 143, 36);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Worker ID");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_4.setBounds(67, 224, 143, 36);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Salary");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_5.setBounds(67, 317, 143, 36);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Absent Days");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_6.setBounds(67, 412, 143, 36);
		panel.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Deduct Amount");
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_7.setBounds(620, 412, 180, 36);
		panel.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Net Salary");
		lblNewLabel_1_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_3_1.setBounds(67, 510, 143, 36);
		panel.add(lblNewLabel_1_3_1);
		
		pay_no = new JTextField();
		pay_no.setBounds(221, 129, 193, 29);
		panel.add(pay_no);
		pay_no.setColumns(10);
		
		worker_id = new JTextField();
		worker_id.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String w_id=worker_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from workers_management where worker_id='"+w_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			
	          			worker_name.setText(rs.getString("worker_name"));
	          			salary.setText(rs.getString("salary"));
	          			
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
				
			}
		});
		worker_id.setColumns(10);
		worker_id.setBounds(220, 224, 356, 29);
		panel.add(worker_id);
		
		worker_name = new JTextField();
		worker_name.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (Character.isAlphabetic(evt.getKeyChar())  || evt.getKeyCode()==46 || evt.getKeyCode()==32 || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {
					worker_name.setEditable(true);
				        
				    }
				 else 
				{
					 worker_name.setEditable(false);
				       
				    }

			}
		});
		worker_name.setColumns(10);
		worker_name.setBounds(810, 232, 356, 29);
		panel.add(worker_name);
		
		salary = new JTextField();
		salary.setColumns(10);
		salary.setBounds(220, 325, 356, 29);
		panel.add(salary);
		
		absent_days = new JTextField();
		absent_days.setColumns(10);
		absent_days.setBounds(221, 420, 356, 29);
		panel.add(absent_days);
		
		net_salary = new JTextField();
		net_salary.setColumns(10);
		net_salary.setBounds(221, 510, 356, 29);
		panel.add(net_salary);
		
		present_days = new JTextField();
		present_days.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Integer p_day = Integer.parseInt(present_days.getText());
				Integer e_salary = Integer.parseInt(salary.getText());
				Integer a_day = 26 - p_day;
				absent_days.setText(String.valueOf(a_day));
				
				Integer d_amt;
				if(a_day != 0)
				{
				d_amt	= 300 * a_day;
				}
				else
				{
					d_amt =0;
				}
				deduct_amount.setText(String.valueOf(d_amt));
				
				Integer n_amt = e_salary - d_amt;
				
				net_salary.setText(String.valueOf(n_amt));
				
			}
		});
		present_days.setColumns(10);
		present_days.setBounds(810, 325, 356, 29);
		panel.add(present_days);
		
		deduct_amount = new JTextField();
		deduct_amount.setColumns(10);
		deduct_amount.setBounds(810, 412, 356, 29);
		panel.add(deduct_amount);
		
		JDateChooser pay_date = new JDateChooser();
		pay_date.setBounds(810, 128, 356, 29);
		panel.add(pay_date);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date date =  pay_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String p_date = formatter.format(date);
				try
				{
					String sql = "insert into workers_salary (  pay_no  , pay_date , worker_id , worker_name , salary , present_days , absent_days , deduct_amount, net_salary  ) values ( '"+pay_no.getText()+"' , '"+p_date+"', '"+worker_id.getText()+"' ,'"+worker_name .getText()+"' , '"+salary.getText()+"' , '"+present_days.getText()+"' ,'"+absent_days.getText()+"' , '"+deduct_amount.getText()+"','"+net_salary.getText()+"') ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					System.out.println(ex.toString());
				}
				
				
			
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(77, 649, 102, 49);
		panel.add(btnNewButton);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "update Workers_Salary set worker_id = '"+worker_id.getText()+"' , pay_no='"+pay_no.getText()+"' ,  worker_name= '"+worker_name.getText()+"' , salary='"+salary.getText()+"' ,  absent_days='"+absent_days.getText()+"' ,  net_salary='"+net_salary.getText()+"' , pay_date='"+pay_date.getDate()+"' , present_days='"+present_days.getText()+"' ,  deduct_amount='"+deduct_amount.getText()+"' where worker_id='"+worker_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnUpdate.setBounds(247, 649, 128, 49);
		panel.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDelete.setBounds(448, 649, 133, 49);
		panel.add(btnDelete);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				worker_id.setText("");
				pay_no.setText("");
				worker_name.setText("");
				salary.setText("");
				absent_days.setText("");
				net_salary.setText("");
				present_days.setText("");
				deduct_amount.setText(null);
				pay_date.setDate(null);
				
				auto_id();
			}
		});
		btnClear.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnClear.setBounds(651, 649, 102, 49);
		panel.add(btnClear);
		
		JButton btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				View_Workers_Salary  obj = new View_Workers_Salary ();
				obj.setVisible(true);
			}
		});
		btnView.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnView.setBounds(825, 649, 102, 49);
		panel.add(btnView);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj =new Home();
				obj.setVisible(true);
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnExit.setBounds(1059, 25, 102, 36);
		panel.add(btnExit);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String p_no=pay_no.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from Workers_Salary where pay_no='"+p_no+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			worker_id.setText(rs.getString("worker_id"));
	          			worker_name.setText(rs.getString("worker_name"));
	          			salary.setText(rs.getString("salary"));
	          			absent_days.setText(rs.getString("absent_days"));
	          			net_salary.setText(rs.getString("net_salary"));
	          			present_days.setText(rs.getString("present_days"));
	          			deduct_amount.setText(rs.getString("deduct_amount"));
	          			pay_date.setDate(rs.getDate("pay_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
				
			
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnSearch.setBounds(424, 128, 141, 29);
		panel.add(btnSearch);
		
		JButton btnNewButton_1 = new JButton("Generate Report");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Workers Salary.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}

		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(988, 650, 193, 49);
		panel.add(btnNewButton_1);
		 auto_id();
	}
}
