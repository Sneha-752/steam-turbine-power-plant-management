import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class User_Management extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField user_id;
	private JTextField user_name;
	private JTextField user_role;
	private JTextField password;
	private JTextField email_address;
	private JTextField contact_number;
	private JTextField last_login_date;
	private JTextField remark;
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User_Management frame = new User_Management();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	public void auto_id()
	 {
		  
		  int count=1;
			try
	     	{
				Connection cn=null;
				Statement st=null;
				
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     		st=cn.createStatement();
	     		String sql="select * from user_management ";
	     		ResultSet rs=st.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("user_id"));
	     			count++;
	     		}
	     		
	     		user_id.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	         System.out.println(ex.toString());
	     }
			}
	

	/**
	 * Create the frame.
	 */
	public User_Management() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1180, 698);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 11, 1144, 637);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("User Management");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(335, 34, 449, 43);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("User ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(107, 129, 114, 29);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("User Name");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(107, 205, 114, 29);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("User Role");
		lblNewLabel_1_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(107, 279, 114, 29);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Contact Number");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(533, 205, 152, 29);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Email Address");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_4.setBounds(533, 129, 152, 29);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Password");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_5.setBounds(107, 355, 114, 29);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Last Login Date");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_6.setBounds(533, 279, 152, 29);
		panel.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Remark");
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_7.setBounds(533, 355, 105, 29);
		panel.add(lblNewLabel_1_7);
		
		user_id = new JTextField();
		user_id.setBounds(228, 129, 152, 27);
		panel.add(user_id);
		user_id.setColumns(10);
		
		user_name = new JTextField();
		user_name.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (Character.isAlphabetic(evt.getKeyChar())  || evt.getKeyCode()==46 || evt.getKeyCode()==32 || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {
					user_name.setEditable(true);
				        
				    }
				 else 
				{
					 user_name.setEditable(false);
				       
				    }

			}
		});
		user_name.setColumns(10);
		user_name.setBounds(228, 207, 257, 27);
		panel.add(user_name);
		
		user_role = new JTextField();
		user_role.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (Character.isAlphabetic(evt.getKeyChar())  || evt.getKeyCode()==46 || evt.getKeyCode()==32 || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {
					user_role.setEditable(true);
				        
				    }
				 else 
				{
					 user_role.setEditable(false);
				       
				    }

			}
		});
		user_role.setColumns(10);
		user_role.setBounds(231, 279, 257, 27);
		panel.add(user_role);
		
		password = new JTextField();
		password.setColumns(10);
		password.setBounds(228, 355, 257, 27);
		panel.add(password);
		
		email_address = new JTextField();
		email_address.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (Character.isAlphabetic(evt.getKeyChar()) || evt.getKeyCode() == evt.VK_BACK_SPACE  || evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' || evt.getKeyCode()==64 || evt.getKeyCode()==46)
				 {
					email_address.setEditable(true);
				        
				    }
				 else 
				 {
					 email_address.setEditable(false);
				       
				    }


			}
		});
		email_address.setColumns(10);
		email_address.setBounds(715, 129, 294, 27);
		panel.add(email_address);
		
		contact_number = new JTextField();
		contact_number.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {

					contact_number.setEditable(true);

				}
				 else
				 {
					 contact_number.setEditable(false);

				}

			}
		});
		contact_number.setColumns(10);
		contact_number.setBounds(715, 207, 294, 27);
		panel.add(contact_number);
		
		remark = new JTextField();
		remark.setColumns(10);
		remark.setBounds(715, 357, 300, 27);
		panel.add(remark);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "delete from user_management where user_id = '"+user_id.getText()+"' ";
					String result = db.delete(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDelete.setBounds(404, 558, 105, 34);
		panel.add(btnDelete);
		
		JButton btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 View_User_Management  obj = new  View_User_Management ();
				obj.setVisible(true);
			}
		});
		btnView.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnView.setBounds(720, 558, 105, 34);
		panel.add(btnView);
		
		JButton btnGenerateReport = new JButton("Generate Report");
		btnGenerateReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\User.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
			
		});
		btnGenerateReport.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnGenerateReport.setBounds(875, 558, 192, 34);
		panel.add(btnGenerateReport);
		
		JButton btnSearch = new JButton("search");
		btnSearch.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String User_id=user_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from user_management where user_id='"+User_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			user_name.setText(rs.getString("user_name"));
	          			user_role.setText(rs.getString("user_role"));
	          			password.setText(rs.getString("password"));
	          			email_address.setText(rs.getString("email_address"));
	          			contact_number.setText(rs.getString("contact_number"));
	          			last_login_date.setText(rs.getString("last_login_date"));
	          			remark.setText(rs.getString("remark"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSearch.setBounds(380, 129, 129, 27);
		panel.add(btnSearch);
		
		JDateChooser last_login_date = new JDateChooser();
		last_login_date.setBounds(715, 279, 294, 29);
		panel.add(last_login_date);
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(1020, 11, 114, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date date = last_login_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String l_date = formatter.format(date);
				try
				{
					String sql = "insert into user_management ( user_id , email_address ,user_name  ,contact_number , user_role , last_login_date, password ,   remark  ) values ( '"+ user_id.getText()+"' , '"+email_address.getText()+"' ,  '"+user_name.getText()+"' ,'"+contact_number.getText()+"' , '"+user_role.getText()+"' ,'"+l_date+"' , '"+password.getText()+"' ,   '"+remark.getText()+"' ) ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(86, 558, 89, 32);
		panel.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "update user_management set user_id = '"+user_id.getText()+"' ,  last_login_date='"+last_login_date.getDate()+"' ,   user_name='"+user_name.getText()+"' ,  user_role= '"+user_role.getText()+"' , password='"+password.getText()+"' ,  email_address='"+email_address.getText()+"' , contact_number='"+contact_number.getText()+"' ,  remark='"+remark.getText()+"'  where user_id='"+user_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(231, 558, 105, 32);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					user_id.setText("");
					user_name.setText("");
					user_role.setText("");
					password.setText("");
					email_address.setText("");
					contact_number.setText("");
					remark.setText("");
					last_login_date.setDate(null);
					auto_id();
				}
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(568, 558, 89, 34);
		panel.add(btnNewButton_3);
		auto_id();
	}
}
