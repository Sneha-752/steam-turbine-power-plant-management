import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JYearChooser;

import groovy.io.FileType;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Boiler_management extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField boiler_id;
	private JTextField boiler_capacity;
	private JTextField steam_pressure;
	private JTextField steam_temperature;
	private JTextField fuel_consumption_rate;
	private JTextField boiler_efficiency;
	private JTextField feed_water_temperature;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Boiler_management frame = new Boiler_management();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

   public void auto_id()
   {
	  String var = "";
	  int count=1;
	  
		try
     	{
			Connection cn=null;
			Statement st=null;
			
			Class.forName("com.mysql.jdbc.Driver");
     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
     		st=cn.createStatement();
     		String sql="select * from boiler_management";
     		ResultSet rs=st.executeQuery(sql);
     		while(rs.next())
     		{
     			count = Integer.parseInt(rs.getString("boiler_id"));
     			count++;
     		}
     		var = String.valueOf(count);
     		boiler_id.setText(String.valueOf(count));
     }
     catch(Exception ex){
     
         System.out.println(ex.toString());
     }
		
   }
	/**
	 * Create the frame.
	 */
	public Boiler_management() {
		setBackground(new Color(255, 255, 255));
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1250, 635);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Boiler Management");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setBounds(321, 11, 509, 56);
		contentPane.add(lblNewLabel);
		
		
		JLabel lblNewLabel_1 = new JLabel("Boiler ID  ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(38, 90, 117, 32);
		contentPane.add(lblNewLabel_1);
		
		boiler_id = new JTextField();
		boiler_id.setBounds(254, 93, 128, 32);
		contentPane.add(boiler_id);
		boiler_id.setColumns(10);
		
		JComboBox boiler_type = new JComboBox();
		boiler_type.setFont(new Font("Tahoma", Font.BOLD, 18));
		boiler_type.setModel(new DefaultComboBoxModel(new String[] {"Bagasse", "Coal", "Biomass"}));
		boiler_type.setBounds(254, 217, 260, 30);
		contentPane.add(boiler_type);
		
		JLabel lblNewLabel_1_1 = new JLabel("Boiler Capacity");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(21, 159, 197, 32);
		contentPane.add(lblNewLabel_1_1);
		
		boiler_capacity = new JTextField();
		boiler_capacity.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				
				if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' || evt.getKeyCode() == evt.VK_BACK_SPACE)
				 {

					boiler_capacity.setEditable(true);

				}
				 else
				 {
					 boiler_capacity.setEditable(false);

				}

			}
		});
		boiler_capacity.setColumns(10);
		boiler_capacity.setBounds(254, 161, 260, 32);
		contentPane.add(boiler_capacity);
		
		JLabel lblNewLabel_1_2 = new JLabel("Boiler Type");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(55, 217, 117, 32);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Steam Pressure");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(10, 278, 217, 32);
		contentPane.add(lblNewLabel_1_3);
		
		steam_pressure = new JTextField();
		steam_pressure.setColumns(10);
		steam_pressure.setBounds(254, 280, 260, 32);
		contentPane.add(steam_pressure);
		
		steam_temperature = new JTextField();
		steam_temperature.setColumns(10);
		steam_temperature.setBounds(254, 348, 260, 32);
		contentPane.add(steam_temperature);
		
		JLabel lblNewLabel_1_6 = new JLabel("Fuel Consumption Rate");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_6.setBounds(576, 159, 236, 32);
		contentPane.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Boiler Efficiency");
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_7.setBounds(576, 217, 169, 32);
		contentPane.add(lblNewLabel_1_7);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 0, 1234, 596);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		JDateChooser last_maintenance_date = new JDateChooser();
		last_maintenance_date.setBounds(812, 279, 260, 32);
		panel.add(last_maintenance_date);
		
		JDateChooser next_maintenance_date = new JDateChooser();
		next_maintenance_date.setBounds(818, 346, 254, 32);
		panel.add(next_maintenance_date);
		
		
		JLabel lblNewLabel_1_8 = new JLabel("Last Maintenance Date");
		lblNewLabel_1_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_8.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_8.setBounds(576, 278, 236, 32);
		contentPane.add(lblNewLabel_1_8);
		
		
		
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(1100, 11, 107, 32);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "update boiler_management set boiler_id = '"+boiler_id.getText()+"' , boiler_capacity='"+boiler_capacity.getText()+"' ,  steam_pressure= '"+steam_pressure.getText()+"' , steam_temperature='"+steam_temperature.getText()+"' ,  fuel_consumption_rate='"+fuel_consumption_rate.getText()+"' ,  last_maintenance_date='"+last_maintenance_date.getDate()+"' , next_maintenance_date='"+next_maintenance_date.getDate()+"' , boiler_efficiency='"+boiler_efficiency.getText()+"' ,  feed_water_temperature='"+feed_water_temperature.getText()+"' where boiler_id='"+boiler_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
				}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(263, 514, 112, 46);
		panel.add(btnNewButton_2);
		
		JLabel lblNewLabel_1_4 = new JLabel("Steam Temperature");
		lblNewLabel_1_4.setBounds(10, 346, 217, 32);
		panel.add(lblNewLabel_1_4);
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JLabel lblNewLabel_1_10 = new JLabel("Feed Water Temperature");
		lblNewLabel_1_10.setBounds(10, 412, 227, 32);
		panel.add(lblNewLabel_1_10);
		lblNewLabel_1_10.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JButton btnNewButton_3_2 = new JButton("Search");
		btnNewButton_3_2.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnNewButton_3_2.setBounds(386, 93, 129, 32);
		panel.add(btnNewButton_3_2);
		btnNewButton_3_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Boiler_id=boiler_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from boiler_management where boiler_id='"+Boiler_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			boiler_capacity.setText(rs.getString("boiler_capacity"));
	          			steam_pressure.setText(rs.getString("steam_pressure"));
	          			steam_temperature.setText(rs.getString("steam_temperature"));
	          			fuel_consumption_rate.setText(rs.getString("fuel_consumption_rate"));
	          			boiler_efficiency.setText(rs.getString("boiler_efficiency"));
	          			feed_water_temperature.setText(rs.getString("feed_water_temperature"));
	          			next_maintenance_date.setDate(rs.getDate("next_maintenance_date"));
	          		    last_maintenance_date.setDate(rs.getDate("last_maintenance_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
				
			
			}
		});
		btnNewButton_3_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JLabel lblNewLabel_2 = new JLabel("Last Maintenance Date");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(566, 279, 236, 32);
		panel.add(lblNewLabel_2);
		
		
		boiler_efficiency = new JTextField();
		boiler_efficiency.setBounds(812, 214, 260, 32);
		panel.add(boiler_efficiency);
		boiler_efficiency.setColumns(10);
		
		fuel_consumption_rate = new JTextField();
		fuel_consumption_rate.setBounds(812, 156, 260, 32);
		panel.add(fuel_consumption_rate);
		fuel_consumption_rate.setColumns(10);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBounds(435, 515, 128, 45);
		panel.add(btnDelete);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "delete from boiler_management where boiler_id = '"+boiler_id.getText()+"' ";
					String result = db.delete(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.setBounds(610, 515, 128, 45);
		panel.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boiler_id.setText("");
				boiler_capacity.setText("");
				steam_pressure.setText("");
				steam_temperature.setText("");
				fuel_consumption_rate.setText("");
				boiler_efficiency.setText("");
				feed_water_temperature.setText("");
				last_maintenance_date.setDate(null);
				next_maintenance_date.setDate(null);
				boiler_type.setSelectedItem("Bagasse");
				auto_id();
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JButton btnNewButton_3_1 = new JButton("View");
		btnNewButton_3_1.setBounds(799, 515, 128, 45);
		panel.add(btnNewButton_3_1);
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Boiler_Management obj = new View_Boiler_Management();
				obj.setVisible(true);
			}
		});
		btnNewButton_3_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JButton btnNewButton_4 = new JButton("Generate Report");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			     Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Boiler Management.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnNewButton_4.setBounds(982, 515, 190, 45);
		panel.add(btnNewButton_4);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		feed_water_temperature = new JTextField();
		feed_water_temperature.setBounds(255, 415, 260, 32);
		panel.add(feed_water_temperature);
		feed_water_temperature.setColumns(10);
		
		JLabel lblNewLabel_1_9 = new JLabel("Next Maintenance Date");
		lblNewLabel_1_9.setBounds(566, 346, 236, 32);
		panel.add(lblNewLabel_1_9);
		lblNewLabel_1_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_9.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		
		
		JComboBox Fuel_type = new JComboBox();
		Fuel_type.setBounds(812, 94, 260, 30);
		panel.add(Fuel_type);
		Fuel_type.setFont(new Font("Tahoma", Font.BOLD, 18));
		Fuel_type.setModel(new DefaultComboBoxModel(new String[] {"Bagasse", "Coal", "Biomass"}));
		
		JLabel lblNewLabel_3 = new JLabel("Fuel Type");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setBounds(609, 93, 129, 32);
		panel.add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date date =  last_maintenance_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String l_date = formatter.format(date);
				
				Date date1 =  next_maintenance_date.getDate();
				SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
				String n_date = formatter1.format(date);
				try
				{
					String sql = "insert into boiler_management (boiler_id , boiler_capacity  , boiler_type , steam_pressure , steam_temperature , fuel_consumption_rate , boiler_efficiency ,feed_water_temperature , fuel_type , last_maintenance_date ,  next_maintenance_date) values ( '"+boiler_id.getText()+"' , '"+boiler_capacity.getText()+"' ,  '"+boiler_type.getSelectedItem()+"' , '"+steam_pressure .getText()+"' , '"+steam_temperature.getText()+"' , '"+fuel_consumption_rate.getText()+"' , '"+boiler_efficiency.getText()+"', '"+feed_water_temperature.getText()+"' , '"+Fuel_type.getSelectedItem()+"' , '"+last_maintenance_date.getDate()+"' , '"+next_maintenance_date.getDate()+"') ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(82, 514, 112, 46);
		panel.add(btnNewButton);
		
		
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj =new Home();
				obj.setVisible(true);
			}
		});
		auto_id();
	}
}

