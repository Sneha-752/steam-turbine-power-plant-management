import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;

public class Reporting_Module extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField start_date;
	private JTextField end_date;
	private JTextField id;
	private JTextField date;
	private JTextField date1;
	private JTextField date2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reporting_Module frame = new Reporting_Module();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

	/**
	 * Create the frame.
	 */
	public Reporting_Module() {
		
		Connection cn =null;
		Statement st =null;
	    Database db = new Database();
	    String result = db.Connectdb();
	    System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1180, 711);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 1144, 650);
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Reporting Module");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(367, 23, 384, 57);
		panel.add(lblNewLabel);
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(1007, 23, 115, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Boilder Report\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Boiler Management.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnNewButton.setBounds(159, 102, 125, 32);
		panel.add(btnNewButton);
		
		JButton btnCostEstimation = new JButton("Cost Estimation");
		btnCostEstimation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Cost Estimation.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnCostEstimation.setBounds(324, 102, 125, 32);
		panel.add(btnCostEstimation);
		
		JButton btnSaleReport = new JButton("Sale Report");
		btnSaleReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Energy Sales.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnSaleReport.setBounds(648, 102, 125, 32);
		panel.add(btnSaleReport);
		
		JButton btnProductionReport = new JButton("Production Report");
		btnProductionReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Energy Production.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnProductionReport.setBounds(484, 102, 125, 32);
		panel.add(btnProductionReport);
		
		JButton btnComplianceReport = new JButton("Compliance Report");
		btnComplianceReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\compilance.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnComplianceReport.setBounds(811, 102, 125, 32);
		panel.add(btnComplianceReport);
		
		JButton btnFuel = new JButton("Fuel Report");
		btnFuel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\fuel.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnFuel.setBounds(159, 158, 125, 32);
		panel.add(btnFuel);
		
		JButton btnMaintanceReport = new JButton("Maintance Report");
		btnMaintanceReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Maintenance Management.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnMaintanceReport.setBounds(324, 158, 125, 32);
		panel.add(btnMaintanceReport);
		
		JButton btnUsersReport = new JButton("Users Report");
		btnUsersReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\User.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnUsersReport.setBounds(484, 158, 125, 32);
		panel.add(btnUsersReport);
		
		JButton btnWorkersReport = new JButton("Workers Report");
		btnWorkersReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Workers Management.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnWorkersReport.setBounds(648, 158, 125, 32);
		panel.add(btnWorkersReport);
		
		JButton btnUsersReport_1_1 = new JButton("Salary Report");
		btnUsersReport_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Workers Salary.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnUsersReport_1_1.setBounds(811, 158, 125, 32);
		panel.add(btnUsersReport_1_1);
		
		id = new JTextField();
		id.setBounds(484, 234, 140, 23);
		panel.add(id);
		id.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Id :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(367, 234, 82, 19);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton_2 = new JButton("Boilder Report\r\n");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        String id1 = id.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Id wise Boiler Management.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("id", id1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
		});
		btnNewButton_2.setBounds(159, 286, 125, 32);
		panel.add(btnNewButton_2);
		
		JButton btnCostEstimation_1 = new JButton("Cost Estimation");
		btnCostEstimation_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id1 = id.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\id_wise_cost_estimation.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("id", id1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnCostEstimation_1.setBounds(324, 286, 125, 32);
		panel.add(btnCostEstimation_1);
		
		JButton btnProductionReport_1 = new JButton("Production Report");
		btnProductionReport_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id1 = id.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\id_wise_production.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("id", id1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnProductionReport_1.setBounds(484, 286, 125, 32);
		panel.add(btnProductionReport_1);
		
		JButton btnSaleReport_1 = new JButton("Sale Report");
		btnSaleReport_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id1 = id.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\id_wise_sale.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("id", id1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnSaleReport_1.setBounds(648, 286, 125, 32);
		panel.add(btnSaleReport_1);
		
		JButton btnMaintanceReport_1 = new JButton("Maintance Report");
		btnMaintanceReport_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id1 = id.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\id_wise_maintanance.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("id", id1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnMaintanceReport_1.setBounds(811, 286, 125, 32);
		panel.add(btnMaintanceReport_1);
		
		JButton btnUsersReport_1 = new JButton("Users Report");
		btnUsersReport_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id1 = id.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\id_wise_users.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("id", id1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnUsersReport_1.setBounds(410, 346, 125, 32);
		panel.add(btnUsersReport_1);
		
		JButton btnWorkersReport_1 = new JButton("Workers Report");
		btnWorkersReport_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id1 = id.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\id_wise_worker.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("id", id1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnWorkersReport_1.setBounds(574, 346, 125, 32);
		panel.add(btnWorkersReport_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Enter Date :");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(366, 406, 93, 19);
		panel.add(lblNewLabel_1_1);
		
		date = new JTextField();
		date.setColumns(10);
		date.setBounds(494, 406, 140, 23);
		panel.add(date);
		
		JButton btnNewButton_3 = new JButton("Boilder Report\r\n");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date1 = date.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_wise_boiler.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date", date1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnNewButton_3.setBounds(169, 450, 125, 32);
		panel.add(btnNewButton_3);
		
		JButton btnCostEstimation_1_1 = new JButton("Cost Estimation");
		btnCostEstimation_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date1 = date.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_wise_costestimation.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date", date1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnCostEstimation_1_1.setBounds(334, 450, 125, 32);
		panel.add(btnCostEstimation_1_1);
		
		JButton btnProductionReport_1_1 = new JButton("Production Report");
		btnProductionReport_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date1 = date.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_wise_production.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date", date1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnProductionReport_1_1.setBounds(494, 450, 125, 32);
		panel.add(btnProductionReport_1_1);
		
		JButton btnSaleReport_1_1 = new JButton("Sale Report");
		btnSaleReport_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date1 = date.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_wise_sale.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date", date1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnSaleReport_1_1.setBounds(658, 450, 125, 32);
		panel.add(btnSaleReport_1_1);
		
		JButton btnComplianceReport_1_1 = new JButton("Compliance Report");
		btnComplianceReport_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date1 = date.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_wise_compliance.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date", date1);		           
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnComplianceReport_1_1.setBounds(821, 450, 125, 32);
		panel.add(btnComplianceReport_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Enter Date :");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_1.setBounds(218, 529, 93, 19);
		panel.add(lblNewLabel_1_1_1);
		
		date1 = new JTextField();
		date1.setColumns(10);
		date1.setBounds(345, 529, 140, 23);
		panel.add(date1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Enter Date :");
		lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1_2.setBounds(534, 529, 93, 19);
		panel.add(lblNewLabel_1_1_2);
		
		date2 = new JTextField();
		date2.setColumns(10);
		date2.setBounds(662, 529, 140, 23);
		panel.add(date2);
		
		JButton btnNewButton_3_1 = new JButton("Boilder Report\r\n");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date11 = date1.getText();
				String date22 = date2.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_btwn_boiler.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date1", date11);	
			           parameters.put("date2", date22);	
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
		           
		           
			}
		});
		btnNewButton_3_1.setBounds(169, 574, 125, 32);
		panel.add(btnNewButton_3_1);
		
		JButton btnCostEstimation_1_1_1 = new JButton("Cost Estimation");
		btnCostEstimation_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date11 = date1.getText();
				String date22 = date2.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_btwn_cost.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date1", date11);	
			           parameters.put("date2", date22);	
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnCostEstimation_1_1_1.setBounds(334, 574, 125, 32);
		panel.add(btnCostEstimation_1_1_1);
		
		JButton btnProductionReport_1_1_1 = new JButton("Production Report");
		btnProductionReport_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date11 = date1.getText();
				String date22 = date2.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_btwn_production.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date1", date11);	
			           parameters.put("date2", date22);	
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnProductionReport_1_1_1.setBounds(494, 574, 125, 32);
		panel.add(btnProductionReport_1_1_1);
		
		JButton btnSaleReport_1_1_1 = new JButton("Sale Report");
		btnSaleReport_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date11 = date1.getText();
				String date22 = date2.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_btwn_sale.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date1", date11);	
			           parameters.put("date2", date22);	
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnSaleReport_1_1_1.setBounds(658, 574, 125, 32);
		panel.add(btnSaleReport_1_1_1);
		
		JButton btnComplianceReport_1_1_1 = new JButton("Compliance Report");
		btnComplianceReport_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date11 = date1.getText();
				String date22 = date2.getText();
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\date_btwn_compilance.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           Map parameters= new HashMap();
			           parameters.put("date1", date11);	
			           parameters.put("date2", date22);	
			           JasperPrint jp=JasperFillManager.fillReport(jr, parameters, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }
			}
		});
		btnComplianceReport_1_1_1.setBounds(821, 574, 125, 32);
		panel.add(btnComplianceReport_1_1_1);
	}
}
