import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;

public class Cost_Estimation_Module extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField cost_id;
	private JTextField boiler_id;
	private JTextField modification_description;
	private JTextField estimated_cost;
	private JTextField actual_cost;
	private JTextField remarks;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cost_Estimation_Module frame = new Cost_Estimation_Module();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	 public void auto_id()
	 {
		 
		  int count=1;
			try
	     	{
				Connection cn=null;
				Statement st=null;
				PreparedStatement pst = null;
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     
	     		String sql="select * from cost_estimation_module";
	     		pst=cn.prepareStatement(sql);
	     		ResultSet rs=pst.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("cost_id"));
	     			count++;
	     		}
	     		
	     		cost_id.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	        JOptionPane.showMessageDialog(null, ex.toString());
	     }
			
	}
	/**
	 * Create the frame.
	 */
	public Cost_Estimation_Module() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1180, 635);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 11, 1144, 574);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Cost Estimation Module");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setBounds(345, 24, 509, 40);
		panel.add(lblNewLabel);
		
		
		JLabel lblNewLabel_1 = new JLabel("Cost ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(77, 124, 136, 40);
		panel.add(lblNewLabel_1);
		
		cost_id = new JTextField();
		cost_id.setBounds(267, 131, 146, 33);
		panel.add(cost_id);
		cost_id.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Boiler ID");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(77, 209, 136, 40);
		panel.add(lblNewLabel_1_1);
		
		JDateChooser cost_date = new JDateChooser();
		cost_date.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		
		cost_date.setBounds(797, 216, 286, 33);
		panel.add(cost_date);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Modification Description");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_1.setBounds(10, 292, 231, 40);
		panel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Estimated Cost");
		lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_2.setBounds(41, 381, 172, 40);
		panel.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_2_1 = new JLabel("Cost Date");
		lblNewLabel_1_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_2_1.setBounds(632, 209, 136, 40);
		panel.add(lblNewLabel_1_1_2_1);
		
		
		
		JLabel lblNewLabel_1_1_2_2 = new JLabel("Remarks");
		lblNewLabel_1_1_2_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_2_2.setBounds(632, 285, 136, 40);
		panel.add(lblNewLabel_1_1_2_2);
		
		JLabel lblNewLabel_1_1_2_3 = new JLabel("Actual Cost");
		lblNewLabel_1_1_2_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_2_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1_2_3.setBounds(632, 124, 136, 40);
		panel.add(lblNewLabel_1_1_2_3);
		
		boiler_id = new JTextField();
		boiler_id.setColumns(10);
		boiler_id.setBounds(267, 216, 146, 33);
		panel.add(boiler_id);
		
		modification_description = new JTextField();
		modification_description.setColumns(10);
		modification_description.setBounds(267, 292, 286, 33);
		panel.add(modification_description);
		
		estimated_cost = new JTextField();
		estimated_cost.setColumns(10);
		estimated_cost.setBounds(267, 375, 286, 33);
		panel.add(estimated_cost);
		
		actual_cost = new JTextField();
		actual_cost.setColumns(10);
		actual_cost.setBounds(797, 131, 286, 33);
		panel.add(actual_cost);
		
		remarks = new JTextField();
		remarks.setColumns(10);
		remarks.setBounds(797, 292, 286, 33);
		panel.add(remarks);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "delete from cost_estimation_module where cost_id = '"+cost_id.getText()+"' ";
					String result = db.delete(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDelete.setBounds(399, 495, 128, 45);
		panel.add(btnDelete);
		
		JButton btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Cost_Estimation_Module obj = new View_Cost_Estimation_Module();
				obj.setVisible(true);
			}
		});
		btnView.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnView.setBounds(715, 495, 128, 45);
		panel.add(btnView);
		
		JButton btnGenerateCostReport = new JButton("Generate Report");
		btnGenerateCostReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\Cost Estimation.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}
			
		});
		btnGenerateCostReport.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnGenerateCostReport.setBounds(882, 495, 194, 45);
		panel.add(btnGenerateCostReport);
		
		JButton btnSearch_1 = new JButton("Search");
		btnSearch_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnSearch_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Boiler_id=boiler_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from cost_estimation_module where boiler_id='"+Boiler_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			modification_description.setText(rs.getString("modification_description"));
	          			estimated_cost.setText(rs.getString("estimated_cost"));
	          			actual_cost.setText(rs.getString("actual_cost"));
	          			remarks.setText(rs.getString("remarks"));
	          			cost_date.setDate(rs.getDate("cost_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
				
			}
		});
		btnSearch_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSearch_1.setBounds(417, 216, 136, 33);
		panel.add(btnSearch_1);
		
		
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
					obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(1027, 11, 107, 27);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date date = cost_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String date1 = formatter.format(date);
				try
				{
					String sql = "insert into cost_estimation_module (cost_id , boiler_id , modification_description  , estimated_cost , actual_cost , remarks , cost_date) values ( '"+cost_id.getText()+"' , '"+boiler_id.getText()+"' , '"+modification_description .getText()+"' , '"+estimated_cost.getText()+"' , '"+actual_cost.getText()+"' , '"+remarks.getText()+"','"+date1+"') ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					System.out.println(ex.toString());
				}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(70, 495, 128, 45);
		panel.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Date date = cost_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String date1 = formatter.format(date);
				try
				{
					String sql = "update cost_estimation_module set cost_id = '"+cost_id.getText()+"' ,  cost_date = '"+date1+"', boiler_id='"+boiler_id.getText()+"' ,  modification_description= '"+modification_description.getText()+"' , estimated_cost='"+estimated_cost.getText()+"' ,  actual_cost='"+actual_cost.getText()+"' ,  remarks='"+remarks.getText()+"' where cost_id='"+cost_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(236, 495, 120, 45);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cost_id.setText("");
				boiler_id.setText("");
				modification_description.setText("");
				estimated_cost.setText("");
				actual_cost.setText("");
				remarks.setText("");
				cost_date.setDate(null);
				auto_id();
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(574, 495, 100, 45);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Search");
		btnNewButton_4.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Cost_id=cost_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from cost_estimation_module where cost_id='"+Cost_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			modification_description.setText(rs.getString("modification_description"));
	          			estimated_cost.setText(rs.getString("estimated_cost"));
	          			actual_cost.setText(rs.getString("actual_cost"));
	          			remarks.setText(rs.getString("remarks"));
	          			cost_date.setDate(rs.getDate("cost_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_4.setBounds(417, 131, 136, 33);
		panel.add(btnNewButton_4);
		auto_id();
	}
}
