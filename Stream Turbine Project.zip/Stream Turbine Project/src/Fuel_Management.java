import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;

public class Fuel_Management extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField fuel_id;
	private JTextField fuel_quantity;
	private JTextField fuel_cost;
	private JTextField fuel_supplier;
	private JTextField fuel_calorific_value;
	private JTextField fuel_consumption_rate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fuel_Management frame = new Fuel_Management();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

       
       
	 public void auto_id()
	 {
		
		  int count=1;
			try
	     	{
				Connection cn=null;
				Statement st=null;
				
				Class.forName("com.mysql.jdbc.Driver");
	     		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	     		st=cn.createStatement();
	     		String sql="select * from fuel_management ";
	     		ResultSet rs=st.executeQuery(sql);
	     		while(rs.next())
	     		{
	     			count = Integer.parseInt(rs.getString("fuel_id"));
	     			count++;
	     		}
	     	
	     		fuel_id.setText(String.valueOf(count));
	     }
	     catch(Exception ex){
	     
	         System.out.println(ex.toString());
	     }
       }
       
	/**
	 * Create the frame.
	 */
	public Fuel_Management() {
		
		Database db=new Database();
		String result=db.Connectdb();
		System.out.println(result);
		
		setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 1180, 734);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 11, 1144, 673);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Fuel Management Module");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(342, 33, 462, 40);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Fuel ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(97, 136, 107, 27);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Fuel Type");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(97, 213, 107, 27);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Fuel Quantity");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(75, 297, 135, 27);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Fuel Calorific Value");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(569, 136, 188, 27);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Fuel Consumption Rate");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_4.setBounds(569, 213, 220, 27);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Fuel Cost");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_5.setBounds(97, 378, 107, 27);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Fuel Supplier");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_6.setBounds(75, 455, 126, 27);
		panel.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Last Delivery Date");
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_7.setBounds(569, 297, 188, 27);
		panel.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Next Delivery Date");
		lblNewLabel_1_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_8.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_8.setBounds(569, 378, 188, 27);
		panel.add(lblNewLabel_1_8);
		
		fuel_id = new JTextField();
		fuel_id.setBounds(229, 136, 135, 26);
		panel.add(fuel_id);
		fuel_id.setColumns(10);
		
		fuel_quantity = new JTextField();
		fuel_quantity.setColumns(10);
		fuel_quantity.setBounds(229, 297, 254, 26);
		panel.add(fuel_quantity);
		
		fuel_cost = new JTextField();
		fuel_cost.setColumns(10);
		fuel_cost.setBounds(229, 379, 254, 26);
		panel.add(fuel_cost);
		
		fuel_supplier = new JTextField();
		fuel_supplier.setColumns(10);
		fuel_supplier.setBounds(229, 455, 254, 26);
		panel.add(fuel_supplier);
		
		fuel_calorific_value = new JTextField();
		fuel_calorific_value.setColumns(10);
		fuel_calorific_value.setBounds(801, 136, 254, 26);
		panel.add(fuel_calorific_value);
		
		fuel_consumption_rate = new JTextField();
		fuel_consumption_rate.setColumns(10);
		fuel_consumption_rate.setBounds(801, 213, 254, 26);
		panel.add(fuel_consumption_rate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "delete from fuel_management where fuel_id = '"+fuel_id.getText()+"' ";
					String result = db.delete(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
					
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDelete.setBounds(369, 589, 114, 34);
		panel.add(btnDelete);
		
		JButton btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Fuel_Management obj = new View_Fuel_Management();
				obj.setVisible(true);
			}
		});
		btnView.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnView.setBounds(698, 589, 114, 34);
		panel.add(btnView);
		
		JButton btnGenerateFuelReport = new JButton("Generate Fuel Report");
		btnGenerateFuelReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection cn=null;
			     
		           try
		           {
			           Class.forName("com.mysql.jdbc.Driver");
			           System.out.println("Driver Registered");
			           cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
			           System.out.println("Connection Success"); 
			           String path="C:\\Project\\Stream Turbine Project\\src\\Report\\fuel.jrxml";
			           JasperDesign design = JRXmlLoader.load(path);
			           //JasperReport report = JasperCompileManager.compileReport(design);
			           JasperReport jr=JasperCompileManager.compileReport(design);
			           
			           JasperPrint jp=JasperFillManager.fillReport(jr, null, cn);
			           JasperViewer jv=new JasperViewer(jp);
			           JasperViewer.viewReport(jp,false);
		           }catch(Exception ex)
		           {
		        	   System.out.println(ex);
		           }

			}

			
		});
		btnGenerateFuelReport.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnGenerateFuelReport.setBounds(861, 589, 237, 34);
		panel.add(btnGenerateFuelReport);
		
		JComboBox fuel_type = new JComboBox();
		fuel_type.setFont(new Font("Tahoma", Font.BOLD, 18));
		fuel_type.setModel(new DefaultComboBoxModel(new String[] {"Bagasse", "Coal", "Biomass"}));
		fuel_type.setBounds(229, 213, 254, 27);
		panel.add(fuel_type);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\s.png"));
		btnSearch.addActionListener(new ActionListener() {
			private JDateChooser last_delivery_date;
			private JDateChooser next_delivery_date;

			public void actionPerformed(ActionEvent e) {
				String Fule_id=fuel_id.getText();
				try
	          	{
					Connection cn=null;
					Statement st=null;
					
					Class.forName("com.mysql.jdbc.Driver");
	          		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/steam_turbine_project","root","root");
	          		st=cn.createStatement();
	          		String sql="select * from fuel_management where fuel_id='"+Fule_id+"' ";
	          		ResultSet rs=st.executeQuery(sql);
	          		while(rs.next())
	          		{
	          			fuel_quantity.setText(rs.getString("fuel_quantity"));
	          			fuel_cost.setText(rs.getString("fuel_cost"));
	          			fuel_supplier.setText(rs.getString("fuel_supplier"));
	          			fuel_calorific_value.setText(rs.getString("fuel_calorific_value"));
	          			fuel_consumption_rate.setText(rs.getString("fuel_consumption_rate"));
	          			last_delivery_date.setDate(rs.getDate("last_delivery_date"));
	          			next_delivery_date.setDate(rs.getDate("next_delivery_date"));
	          		}
	          }
	          catch(Exception ex){
	          
	              System.out.println(ex.toString());
	          }
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSearch.setBounds(369, 136, 135, 27);
		panel.add(btnSearch);
		
		JDateChooser last_delivery_date = new JDateChooser();
		last_delivery_date.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		last_delivery_date.setBounds(801, 297, 254, 27);
		panel.add(last_delivery_date);
		
		
		JDateChooser next_delivery_date = new JDateChooser();
		next_delivery_date.setBounds(801, 378, 254, 27);
		panel.add(next_delivery_date);
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\1286853.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(1027, 11, 107, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date date = last_delivery_date.getDate();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String l_date = formatter.format(date);
				try
				{
					String sql = "insert into fuel_management (fuel_id , fuel_calorific_value , fuel_type ,fuel_consumption_rate , fuel_quantity  ,last_delivery_date , fuel_cost , next_delivery_date ,fuel_supplier ) values ( '"+fuel_id.getText()+"' ,  '"+fuel_calorific_value.getText()+"' , '"+fuel_type.getSelectedItem()+"' ,'"+fuel_consumption_rate.getText()+"','"+fuel_quantity.getText()+"' , '"+l_date+"' ,  '"+fuel_cost .getText()+"' ,'"+next_delivery_date.getDate()+"' , '"+fuel_supplier.getText()+"'   ) ";
					String result = db.Insert(sql);
					JOptionPane.showMessageDialog(null, result);
				}
				catch(Exception ex)  
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(53, 589, 107, 32);
		panel.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String sql = "update fuel_management set fuel_id = '"+fuel_id.getText()+"' , fuel_quantity='"+fuel_quantity.getText()+"' ,  fuel_cost= '"+fuel_cost.getText()+"' , fuel_supplier='"+fuel_supplier.getText()+"' , last_delivery_date='"+last_delivery_date.getDate()+"' , next_delivery_date='"+next_delivery_date.getDate()+"' ,  fuel_calorific_value='"+fuel_calorific_value.getText()+"' , fuel_consumption_rate='"+fuel_consumption_rate.getText()+"'  where fuel_id='"+fuel_id.getText()+"' "; 
					String result = db.update(sql);
					JOptionPane.showMessageDialog(null, result);
					
				}
				catch(Exception ex)
				{
					System.out.println(ex.toString());
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(213, 589, 107, 34);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {{
		    	   fuel_id.setText("");
		    	   fuel_quantity.setText("");
		    	   fuel_cost.setText("");
		    	   fuel_supplier.setText("");
		    	   fuel_calorific_value.setText("");
		    	   fuel_consumption_rate.setText("");
		    	   last_delivery_date.setDate(null);
		    	   next_delivery_date.setDate(null);
				   fuel_type.setSelectedItem("Bagasse");
		    	   auto_id();
		       }
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(544, 589, 99, 34);
		panel.add(btnNewButton_3);
		
		auto_id();
	}
}
