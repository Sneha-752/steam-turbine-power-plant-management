import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;

public class Home extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1380, 847);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 89, 89));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(93, 11, 1164, 727);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Home");
		lblNewLabel.setFont(new Font("Vineta BT", Font.BOLD, 38));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(474, 11, 193, 41);
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Boiler Management");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Boiler_management obj = new Boiler_management();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 17));
		btnNewButton.setBounds(69, 189, 240, 30);
		panel.add(btnNewButton);
		
		JButton btnCostestimationmodule = new JButton("Cost Estimation");
		btnCostestimationmodule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				Cost_Estimation_Module obj = new Cost_Estimation_Module();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnCostestimationmodule.setFont(new Font("Verdana", Font.BOLD, 17));
		btnCostestimationmodule.setBounds(69, 490, 241, 30);
		panel.add(btnCostestimationmodule);
		
		JButton btnEnergyproduction = new JButton("Energy Production");
		btnEnergyproduction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Energy_Production_Module obj = new Energy_Production_Module();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnEnergyproduction.setFont(new Font("Verdana", Font.BOLD, 17));
		btnEnergyproduction.setBounds(450, 189, 241, 30);
		panel.add(btnEnergyproduction);
		
		JButton btnEnergysalesmodule = new JButton("Energy Sales");
		btnEnergysalesmodule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Energy_Sales_Module obj = new Energy_Sales_Module();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnEnergysalesmodule.setFont(new Font("Verdana", Font.BOLD, 17));
		btnEnergysalesmodule.setBounds(450, 341, 241, 30);
		panel.add(btnEnergysalesmodule);
		
		JButton btnEnvironmentalcompliancemodule = new JButton("Environmental Compliance");
		btnEnvironmentalcompliancemodule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Environmental_Compliance_Module obj = new Environmental_Compliance_Module();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnEnvironmentalcompliancemodule.setFont(new Font("Verdana", Font.BOLD, 17));
		btnEnvironmentalcompliancemodule.setBounds(450, 490, 291, 30);
		panel.add(btnEnvironmentalcompliancemodule);
		
		JButton btnFuelmanagement = new JButton("Fule Management");
		btnFuelmanagement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Fuel_Management obj = new Fuel_Management();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnFuelmanagement.setFont(new Font("Verdana", Font.BOLD, 17));
		btnFuelmanagement.setBounds(462, 640, 240, 30);
		panel.add(btnFuelmanagement);
		
		JButton btnUsermanagement = new JButton("User Management");
		btnUsermanagement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				User_Management obj = new User_Management();
				obj.setVisible(true);
				Home.this.dispose();
				}
		});
		btnUsermanagement.setFont(new Font("Verdana", Font.BOLD, 17));
		btnUsermanagement.setBounds(839, 490, 240, 30);
		panel.add(btnUsermanagement);
		
		JButton btnMaintenancemanagement = new JButton("Maintenance");
		btnMaintenancemanagement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Maintenance_Management obj = new Maintenance_Management();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnMaintenancemanagement.setFont(new Font("Verdana", Font.BOLD, 17));
		btnMaintenancemanagement.setBounds(839, 178, 240, 30);
		panel.add(btnMaintenancemanagement);
		
		JButton btnReportingmodule = new JButton("Reporting");
		btnReportingmodule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Reporting_Module obj = new Reporting_Module();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnReportingmodule.setFont(new Font("Verdana", Font.BOLD, 17));
		btnReportingmodule.setBounds(839, 341, 240, 30);
		panel.add(btnReportingmodule);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-13 at 6.10.21 AM.jpg"));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(116, 86, 146, 103);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-13 at 6.10.22 AM (1).jpg"));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(116, 389, 146, 103);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("");
		lblNewLabel_1_2.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-17 at 5.26.00 AM.jpg"));
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setBounds(116, 541, 146, 113);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("");
		lblNewLabel_1_3.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-13 at 6.10.25 AM.jpg"));
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setBounds(499, 86, 146, 103);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("");
		lblNewLabel_1_4.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-13 at 6.10.26 AM.jpg"));
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setBounds(499, 241, 146, 103);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("");
		lblNewLabel_1_5.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-13 at 6.10.27 AM.jpg"));
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setBounds(499, 389, 146, 103);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("");
		lblNewLabel_1_6.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-13 at 6.10.30 AM.jpg"));
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setBounds(499, 541, 146, 103);
		panel.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("");
		lblNewLabel_1_7.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-14 at 9.25.01 AM.jpg"));
		lblNewLabel_1_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_7.setBounds(892, 68, 146, 113);
		panel.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("");
		lblNewLabel_1_8.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-13 at 6.10.28 AM.jpg"));
		lblNewLabel_1_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_8.setBounds(892, 228, 146, 113);
		panel.add(lblNewLabel_1_8);
		
		JLabel lblNewLabel_1_9 = new JLabel("");
		lblNewLabel_1_9.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-13 at 6.10.29 AM (1).jpg"));
		lblNewLabel_1_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_9.setBounds(892, 389, 146, 103);
		panel.add(lblNewLabel_1_9);
		
		JLabel lblNewLabel_1_11 = new JLabel("");
		lblNewLabel_1_11.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\WhatsApp Image 2025-03-17 at 5.26.02 AM.jpg"));
		lblNewLabel_1_11.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_11.setBounds(116, 241, 146, 103);
		panel.add(lblNewLabel_1_11);
		
		JButton btnNewButton_1 = new JButton("Workers Management");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Workers_Management obj = new Workers_Management();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(69, 341, 240, 30);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Workers Salary");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Workers_Salary obj = new Workers_Salary();
				obj.setVisible(true);
				Home.this.dispose();
			}
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1_1.setBounds(69, 651, 240, 30);
		panel.add(btnNewButton_1_1);
		
		JButton btnFuelmanagement_1 = new JButton("Logout");
		btnFuelmanagement_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login obj = new Login();
				obj.setVisible(true);
				Home.this.dispose();
			}
		
			
		});
		btnFuelmanagement_1.setFont(new Font("Verdana", Font.BOLD, 17));
		btnFuelmanagement_1.setBounds(864, 651, 193, 30);
		panel.add(btnFuelmanagement_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Project\\Stream Turbine Project\\src\\images\\20250313_230821 (1).png"));
		lblNewLabel_2.setBounds(877, 541, 154, 127);
		panel.add(lblNewLabel_2);
	}
}
